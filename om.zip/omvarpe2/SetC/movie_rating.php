<?php
// Load the XML file
$xml = simplexml_load_file("movies.xml") or die("Error: Cannot load XML file.");

// Movie title and new rating
$movieTitle = "Inception";
$newRating = "9.0";

// Loop through movies and update rating
foreach ($xml->movie as $movie) {
    if ((string)$movie->title === $movieTitle) {
        $movie->rating = $newRating;
        break; // stop after updating the first match
    }
}

// Save changes back to the XML file
$xml->asXML("movies.xml");

echo "Rating for '$movieTitle' updated to $newRating successfully!";
?>
