<?php
$doc = new DOMDocument("1.0","UTF-8");

$bookInfo = $doc->createElement("BookInfo");
$doc->appendChild($bookInfo);

$book1 = $doc->createElement("book");
$book1->appendChild($doc->createElement("bookno","1"));
$book1->appendChild($doc->createElement("bookname","JAVA"));
$book1->appendChild($doc->createElement("authorname","Balguru Swami"));
$book1->appendChild($doc->createElement("price","250"));
$book1->appendChild($doc->createElement("year","2006"));
$bookInfo->appendChild($book1);

$book2 = $doc->createElement("book");
$book2->appendChild($doc->createElement("bookno","2"));
$book2->appendChild($doc->createElement("bookname","C"));
$book2->appendChild($doc->createElement("authorname","Denis Ritchie"));
$book2->appendChild($doc->createElement("price","500"));
$book2->appendChild($doc->createElement("year","1971"));
$bookInfo->appendChild($book2);

echo htmlspecialchars($doc->saveXML());
$doc->save("books.xml");
?>
