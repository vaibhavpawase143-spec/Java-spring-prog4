<?php
$xmldoc = new DOMDocument();
$xmldoc->load("Item.xml");
$x = $xmldoc->documentElement;
foreach ($x->childNodes as $item){
    print $item->nodeName. " = ".$item->nodeValue."<br>";
}
?>