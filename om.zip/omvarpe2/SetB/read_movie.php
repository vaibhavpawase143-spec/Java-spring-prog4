<?php
$doc = new DOMDocument();
$doc->load("Movie.xml");

$movies = $doc->getElementsByTagName("Movie");

foreach ($movies as $movie) {
    $title = $movie->getElementsByTagName("MovieTitle")->item(0)->nodeValue;
    $actor = $movie->getElementsByTagName("ActorName")->item(0)->nodeValue;

    echo "Movie Title: " . $title . "<br>";
    echo "Actor Name: " . $actor . "<br><br>";
}
?>
