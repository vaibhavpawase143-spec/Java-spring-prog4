<?php
// Load the XML file into a SimpleXML object
$xml = simplexml_load_file("book.xml") or die("Error: Cannot load book.xml");

// Loop through each <book> element
foreach ($xml->book as $book) {
    echo "Book No: " . $book->bookno . "<br>";
    echo "Book Name: " . $book->bookname . "<br>";
    echo "Author Name: " . $book->authorname . "<br>";
    echo "Price: " . $book->price . "<br>";
    echo "Year: " . $book->year . "<br>";
    echo "<hr>";
}
?>
