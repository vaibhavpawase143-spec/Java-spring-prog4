<?php
// Load the XML file
$xml = simplexml_load_file("students.xml") or die("Error: Cannot load XML file.");

// Fetch and display all <name> elements
foreach ($xml->Student as $student) {
    echo "Name: " . $student->name . "<br>";
}
?>
