<?php

$text = $_GET['name'];

if (in_array(strtolower($text), ["rohit", "dhoni"])) {
    echo "Hello, master " . ucfirst($text) . "!";
} elseif (empty($text)) {
    echo "Stranger, please tell me your name!";
} else {
    echo $text . ", I don’t know you!";
}

?>