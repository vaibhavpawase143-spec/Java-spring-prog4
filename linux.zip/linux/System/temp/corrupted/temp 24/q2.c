// Write a C program to implement the toy shell. It should display the
// command prompt “myshell$”. Tokenize the command line and execute
// the given command by creating the child process. Additionally it should
// interpret the following commands.
// count c filename :- To print number of characters in the file.
// count w filename :- To print number of words in the file.
// count l filename :- To print number of lines in the file.


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_LINE 1024
#define MAX_ARGS 100

void count_chars(char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return;
    }
    int count = 0;
    int ch;
    while ((ch = fgetc(fp)) != EOF) {
        count++;
    }
    fclose(fp);
    printf("Characters: %d\n", count);
}

void count_words(char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return;
    }
    int count = 0;
    char word[256];
    while (fscanf(fp, "%255s", word) == 1) {
        count++;
    }
    fclose(fp);
    printf("Words: %d\n", count);
}

void count_lines(char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return;
    }
    int count = 0;
    int ch;
    while ((ch = fgetc(fp)) != EOF) {
        if (ch == '\n')
            count++;
    }
    fclose(fp);
    printf("Lines: %d\n", count);
}

int main() {
    char line[MAX_LINE];
    char *args[MAX_ARGS];
    pid_t pid;
    int status;

    while (1) {
        printf("myshell$ ");
        if (!fgets(line, sizeof(line), stdin)) {
            // EOF or error
            printf("\n");
            break;
        }

        // Remove trailing newline
        line[strcspn(line, "\n")] = 0;

        // Tokenize input line
        int argc = 0;
        char *token = strtok(line, " ");
        while (token != NULL && argc < MAX_ARGS - 1) {
            args[argc++] = token;
            token = strtok(NULL, " ");
        }
        args[argc] = NULL;

        if (argc == 0)
            continue;  // Empty input

        // Built-in command to exit shell
        if (strcmp(args[0], "exit") == 0) {
            break;
        }

        // Check for "count" commands
        if (strcmp(args[0], "count") == 0) {
            if (argc != 3) {
                printf("Usage: count [c|w|l] filename\n");
                continue;
            }

            if (strcmp(args[1], "c") == 0) {
                count_chars(args[2]);
            } else if (strcmp(args[1], "w") == 0) {
                count_words(args[2]);
            } else if (strcmp(args[1], "l") == 0) {
                count_lines(args[2]);
            } else {
                printf("Invalid count option. Use c, w, or l.\n");
            }
            continue;
        }

        // For other commands, fork and exec
        pid = fork();

        if (pid < 0) {
            perror("Fork failed");
        } else if (pid == 0) {
            // Child process
            execvp(args[0], args);
            // If execvp returns, there was an error
            perror("exec failed");
            exit(1);
        } else {
            // Parent process waits
            waitpid(pid, &status, 0);
        }
    }

    printf("Exiting myshell.\n");
    return 0;
}
