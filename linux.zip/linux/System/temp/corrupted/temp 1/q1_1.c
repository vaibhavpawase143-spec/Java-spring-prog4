// Write the simulation program to implement demand paging and show the
// page scheduling and total number of page faults according to the LRU page
// replacement algorithm. Assume the memory of n frames.
// Reference String : 3,4,5,4,3,4,7,2,4,5,6,7,2,4,6

#include <stdio.h>

int main() {
    int n;  
    int ref_str[] = {3,4,5,4,3,4,7,2,4,5,6,7,2,4,6}; 
    int len = sizeof(ref_str)/sizeof(ref_str[0]);
    
    printf("Enter number of frames: ");
    scanf("%d", &n);
    
    int frames[n];
    int time[n];   
    int i, j;
    
    
    for(i = 0; i < n; i++) {
        frames[i] = -1;
        time[i] = 0;
    }
    
    int page_faults = 0, timer = 0;
    
    printf("\nPage Reference\tFrames\n");
    printf("----------------------------\n");
    
    for(i = 0; i < len; i++) {
        int page = ref_str[i];
        int flag = 0; 
       
        for(j = 0; j < n; j++) {
            if(frames[j] == page) {
                flag = 1; 
                timer++;
                time[j] = timer;  
                break;
            }
        }
        
      
        if(flag == 0) {
            page_faults++;
            timer++;
            
            
            int lru_index = 0, min_time = time[0];
            for(j = 1; j < n; j++) {
                if(time[j] < min_time) {
                    min_time = time[j];
                    lru_index = j;
                }
            }
            
            frames[lru_index] = page;
            time[lru_index] = timer;
        }
        
        printf("%d\t\t", page);
        for(j = 0; j < n; j++) {
            if(frames[j] != -1)
                printf("%d ", frames[j]);
            else
                printf("- ");
        }
        printf("\n");
    }
    
    printf("\nTotal Page Faults = %d\n", page_faults);
    
    return 0;
}
