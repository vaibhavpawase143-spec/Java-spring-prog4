// Write a C program to implement the shell. It should display the command
// prompt “myshell$”. Tokenize the command line and execute the given
// command by creating the child process. Additionally it should interpret the
// following „list‟ commands as
// myshell$ list f dirname :- To print names of all the files in current
// directory.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <dirent.h>
#include <sys/stat.h>

#define MAX 1024
#define MAX_ARGS 100

void execute_command(char *args[]) {
    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
    } else if (pid == 0) {
        // Child process
        if (execvp(args[0], args) < 0) {
            perror("Command execution failed");
        }
        exit(0);
    } else {
        // Parent process waits
        wait(NULL);
    }
}

// Custom list f dirname command
void list_files_only(const char *dirname) {
    struct dirent *de;
    struct stat st;
    char path[1024];

    DIR *dr = opendir(dirname);

    if (dr == NULL) {
        perror("Could not open directory");
        return;
    }

    while ((de = readdir(dr)) != NULL) {
        snprintf(path, sizeof(path), "%s/%s", dirname, de->d_name);

        if (stat(path, &st) == 0 && S_ISREG(st.st_mode)) {
            printf("%s\n", de->d_name); // Print only regular files
        }
    }

    closedir(dr);
}

int main() {
    char input[MAX];
    char *args[MAX_ARGS];

    while (1) {
        printf("myshell$ ");
        fflush(stdout);

        // Take input
        if (!fgets(input, sizeof(input), stdin))
            break;

        // Remove newline
        input[strcspn(input, "\n")] = 0;

        // Exit command
        if (strcmp(input, "exit") == 0)
            break;

        // Tokenize input
        int i = 0;
        char *token = strtok(input, " ");
        while (token != NULL && i < MAX_ARGS - 1) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL;

        // Check for "list f dirname"
        if (i == 3 && strcmp(args[0], "list") == 0 && strcmp(args[1], "f") == 0) {
            list_files_only(args[2]);
        } else if (args[0] != NULL) {
            execute_command(args); // Normal command
        }
    }

    return 0;
}
