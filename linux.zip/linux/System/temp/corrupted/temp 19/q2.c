// Write the simulation program for Round Robin scheduling for given time
// quantum. The arrival time and first CPU-burst of different jobs should be
// inputto the system. Accept no. of Processes, arrival time and burst time.
// The outputshould give the Gantt chart, turnaround time and waiting time
// for each process. Also display the average turnaround time and average
// waiting time.

#include <stdio.h>

struct Process {
    int pid;
    int arrival;
    int burst;
    int remaining;
    int completion;
    int waiting;
    int turnaround;
    int started; // for Gantt chart
};

int main() {
    int n, tq;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process p[n];

    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter Arrival Time for Process P%d: ", p[i].pid);
        scanf("%d", &p[i].arrival);
        printf("Enter Burst Time for Process P%d: ", p[i].pid);
        scanf("%d", &p[i].burst);
        p[i].remaining = p[i].burst;
        p[i].started = 0;
    }

    printf("Enter Time Quantum: ");
    scanf("%d", &tq);

    int completed = 0, time = 0;
    float totalWT = 0, totalTAT = 0;

    printf("\nGantt Chart:\n|");

    while (completed < n) {
        int done = 1;

        for (int i = 0; i < n; i++) {
            if (p[i].remaining > 0 && p[i].arrival <= time) {
                done = 0;

                if (p[i].remaining > tq) {
                    printf(" P%d |", p[i].pid);
                    time += tq;
                    p[i].remaining -= tq;
                } else {
                    printf(" P%d |", p[i].pid);
                    time += p[i].remaining;
                    p[i].completion = time;
                    p[i].remaining = 0;
                    completed++;
                }
            }
        }

        // If no process is ready to execute, move time forward
        if (done) {
            time++;
        }
    }

    // Print time stamps below Gantt chart
    printf("\n0");
    time = 0;
    completed = 0;
    while (completed < n) {
        for (int i = 0; i < n; i++) {
            if (p[i].burst > 0 && p[i].arrival <= time && p[i].remaining < p[i].burst) {
                int t = (p[i].burst - p[i].remaining > tq) ? tq : p[i].burst - p[i].remaining;
                time += t;
                printf("   %d", time);
                p[i].burst = 0; // Avoid printing multiple times
                completed++;
            }
        }
    }

    // Calculate WT and TAT
    for (int i = 0; i < n; i++) {
        p[i].turnaround = p[i].completion - p[i].arrival;
        p[i].waiting = p[i].turnaround - p[i].burst;
        totalWT += p[i].waiting;
        totalTAT += p[i].turnaround;
    }

    printf("\n\nProcess\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n",
               p[i].pid, p[i].arrival, p[i].completion - p[i].arrival - p[i].waiting, // Original BT
               p[i].completion, p[i].turnaround, p[i].waiting);
    }

    printf("\nAverage Waiting Time: %.2f", totalWT / n);
    printf("\nAverage Turnaround Time: %.2f\n", totalTAT / n);

    return 0;
}
