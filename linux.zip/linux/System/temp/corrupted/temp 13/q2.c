// Write the simulation program for Round Robin scheduling for given time
// quantum. The arrival time and first CPU-burst of different jobs should be
// inputto the system. Accept no. of Processes, arrival time and burst time.
// The outputshould give the Gantt chart, turnaround time and waiting time
// for each process. Also display the average turnaround time and average
// waitingtime.

#include <stdio.h>

typedef struct {
    int pid;
    int arrival_time;
    int burst_time;
    int remaining_time;
    int completion_time;
    int waiting_time;
    int turnaround_time;
} Process;

int main() {
    int n, time_quantum;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    Process p[n];
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter arrival time for process %d: ", i + 1);
        scanf("%d", &p[i].arrival_time);
        printf("Enter burst time for process %d: ", i + 1);
        scanf("%d", &p[i].burst_time);
        p[i].remaining_time = p[i].burst_time;
    }

    printf("Enter time quantum: ");
    scanf("%d", &time_quantum);

    int time = 0, completed = 0;
    int queue[n], front = 0, rear = 0;
    int visited[n];
    for (int i = 0; i < n; i++) visited[i] = 0;

    // Enqueue function
    void enqueue(int val) {
        queue[rear++] = val;
    }

    // Dequeue function
    int dequeue() {
        return queue[front++];
    }

    // Initialize by enqueue processes which have arrived at time 0
    for (int i = 0; i < n; i++) {
        if (p[i].arrival_time <= time && !visited[i]) {
            enqueue(i);
            visited[i] = 1;
        }
    }

    printf("\nGantt Chart:\n|");

    while (completed < n) {
        if (front == rear) {  // No process in queue, move time forward
            time++;
            for (int i = 0; i < n; i++) {
                if (p[i].arrival_time <= time && !visited[i]) {
                    enqueue(i);
                    visited[i] = 1;
                }
            }
            continue;
        }

        int idx = dequeue();
        printf(" P%d |", p[idx].pid);

        if (p[idx].remaining_time > time_quantum) {
            time += time_quantum;
            p[idx].remaining_time -= time_quantum;
        } else {
            time += p[idx].remaining_time;
            p[idx].remaining_time = 0;
            completed++;
            p[idx].completion_time = time;
            p[idx].turnaround_time = p[idx].completion_time - p[idx].arrival_time;
            p[idx].waiting_time = p[idx].turnaround_time - p[idx].burst_time;
        }

        // Check for new arrivals during this time
        for (int i = 0; i < n; i++) {
            if (p[i].arrival_time <= time && !visited[i]) {
                enqueue(i);
                visited[i] = 1;
            }
        }

        // If current process is not finished, re-enqueue it
        if (p[idx].remaining_time > 0) {
            enqueue(idx);
        }
    }

    printf("\n\nProcess\tArrival\tBurst\tCompletion\tTurnaround\tWaiting\n");
    float total_tat = 0, total_wt = 0;
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t\t%d\t\t%d\n", p[i].pid, p[i].arrival_time, p[i].burst_time,
               p[i].completion_time, p[i].turnaround_time, p[i].waiting_time);
        total_tat += p[i].turnaround_time;
        total_wt += p[i].waiting_time;
    }

    printf("\nAverage Turnaround Time = %.2f\n", total_tat / n);
    printf("Average Waiting Time = %.2f\n", total_wt / n);

    return 0;
}
