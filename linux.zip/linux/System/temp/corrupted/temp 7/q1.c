// Write the simulation program for demand paging and show the page
// scheduling and total number of page faults according the Optimal page
// replacement algorithm. Assume the memory of n frames.
// Reference String : 7, 5, 4, 8, 5, 7, 2, 3, 1, 3, 5, 9, 4, 6, 2

#include <stdio.h>

int find_optimal_index(int frames[], int n, int ref_str[], int len, int current_index) {
    int i, j;
    int farthest = current_index;
    int index = -1;

    for (i = 0; i < n; i++) {
        int found = 0;
        for (j = current_index + 1; j < len; j++) {
            if (frames[i] == ref_str[j]) {
                if (j > farthest) {
                    farthest = j;
                    index = i;
                }
                found = 1;
                break;
            }
        }
        if (!found) {
            return i;  // Not found in future, best candidate to replace
        }
    }
    if (index == -1) return 0;  // All pages used soon, replace first
    return index;
}

int main() {
    int n;
    int ref_str[] = {7,5,4,8,5,7,2,3,1,3,5,9,4,6,2};
    int len = sizeof(ref_str) / sizeof(ref_str[0]);

    printf("Enter number of frames: ");
    scanf("%d", &n);

    int frames[n];
    int i, j;
    int page_faults = 0;

    for (i = 0; i < n; i++)
        frames[i] = -1;

    printf("\nPage Reference\tFrames\n");

    for (i = 0; i < len; i++) {
        int page = ref_str[i];
        int found = 0;

        for (j = 0; j < n; j++) {
            if (frames[j] == page) {
                found = 1;
                break;
            }
        }

        if (!found) {
            page_faults++;
            int empty_index = -1;
            for (j = 0; j < n; j++) {
                if (frames[j] == -1) {
                    empty_index = j;
                    break;
                }
            }
            if (empty_index != -1) {
                frames[empty_index] = page;
            } else {
                int replace_index = find_optimal_index(frames, n, ref_str, len, i);
                frames[replace_index] = page;
            }
        }

        printf("%d\t\t", page);
        for (j = 0; j < n; j++) {
            if (frames[j] != -1)
                printf("%d ", frames[j]);
            else
                printf("- ");
        }
        printf("\n");
    }

    printf("\nTotal Page Faults = %d\n", page_faults);

    return 0;
}
