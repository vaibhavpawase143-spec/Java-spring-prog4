// Write a program to implement the shell. It should display the command
// prompt “myshell$”. Tokenize the command line and execute the given
// command by creating the child process. Additionally it should interpret
// thefollowing „list‟ commands as
// myshell$ list f dirname:- To print names of all the files in current directory.
// myshell$ list n dirname :- To print the number of all entries in the current
// directory

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <dirent.h>

#define MAX_CMD_LEN 1024
#define MAX_ARGS 100

void list_files(char *dirname) {
    DIR *dir = opendir(dirname);
    if (!dir) {
        perror("opendir error");
        return;
    }
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG) {
            printf("%s\n", entry->d_name);
        }
    }
    closedir(dir);
}

void list_entries_count(char *dirname) {
    DIR *dir = opendir(dirname);
    if (!dir) {
        perror("opendir error");
        return;
    }
    struct dirent *entry;
    int count = 0;
    while ((entry = readdir(dir)) != NULL) {
        count++;
    }
    printf("Total entries: %d\n", count);
    closedir(dir);
}

int main() {
    char input[MAX_CMD_LEN];
    char *args[MAX_ARGS];

    while (1) {
        printf("myshell$ ");
        if (fgets(input, sizeof(input), stdin) == NULL) {
            printf("\n");
            break;
        }
        input[strcspn(input, "\n")] = 0;
        if (strlen(input) == 0) continue;

        int i = 0;
        char *token = strtok(input, " ");
        while (token != NULL && i < MAX_ARGS - 1) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL;

        if (strcmp(args[0], "exit") == 0) break;

        if (strcmp(args[0], "list") == 0) {
            if (i == 3) {
                if (strcmp(args[1], "f") == 0) {
                    list_files(args[2]);
                    continue;
                }
                else if (strcmp(args[1], "n") == 0) {
                    list_entries_count(args[2]);
                    continue;
                }
            }
            printf("Usage:\nlist f dirname\nlist n dirname\n");
            continue;
        }

        pid_t pid = fork();
        if (pid < 0) {
            perror("fork failed");
        } else if (pid == 0) {
            execvp(args[0], args);
            perror("command execution failed");
            exit(1);
        } else {
            wait(NULL);
        }
    }
    return 0;
}
