// Write a programto implement the shell. It should display the command
// prompt “myshell$”. Tokenize the command line and execute the given
// command by creating the child process. Additionally it should interpret
// the following commands.
// myshell$ search f filename pattern :- To display first occurrence of

// pattern in the file.

// myshell$ search a filename pattern :- To search all the occurrence of
// pattern in the file.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_CMD_LEN 1024
#define MAX_ARGS 100

void search_first_occurrence(char *filename, char *pattern) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return;
    }
    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, pattern) != NULL) {
            printf("First occurrence: %s", line);
            fclose(fp);
            return;
        }
    }
    printf("Pattern not found.\n");
    fclose(fp);
}

void search_all_occurrences(char *filename, char *pattern) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return;
    }
    char line[1024];
    int found = 0;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, pattern) != NULL) {
            printf("%s", line);
            found = 1;
        }
    }
    if (!found) printf("Pattern not found.\n");
    fclose(fp);
}

int main() {
    char input[MAX_CMD_LEN];
    char *args[MAX_ARGS];

    while (1) {
        printf("myshell$ ");
        if (fgets(input, sizeof(input), stdin) == NULL) {
            printf("\n");
            break;
        }
        input[strcspn(input, "\n")] = 0;
        if (strlen(input) == 0) continue;

        int i = 0;
        char *token = strtok(input, " ");
        while (token != NULL && i < MAX_ARGS - 1) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL;

        if (strcmp(args[0], "exit") == 0) break;

        if (strcmp(args[0], "search") == 0) {
            if (i == 4 && strcmp(args[1], "f") == 0) {
                search_first_occurrence(args[2], args[3]);
                continue;
            } else if (i == 4 && strcmp(args[1], "a") == 0) {
                search_all_occurrences(args[2], args[3]);
                continue;
            } else {
                printf("Usage:\nsearch f filename pattern\nsearch a filename pattern\n");
                continue;
            }
        }

        pid_t pid = fork();
        if (pid < 0) {
            perror("fork failed");
        } else if (pid == 0) {
            execvp(args[0], args);
            perror("command execution failed");
            exit(1);
        } else {
            wait(NULL);
        }
    }
    return 0;
}
