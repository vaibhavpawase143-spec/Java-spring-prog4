// Write a C program to simulate Non-preemptive Shortest Job First (SJF)
// scheduling. The arrival time and first CPU-burst of different jobs
// should be input to the system. Accept no. of Processes, arrival time ,
// burst time. The output should give Gantt chart, turnaround time &
// waiting time for each process. Also find the average waiting time &
// turnaround

#include <stdio.h>

typedef struct {
    int pid;
    int arrival_time;
    int burst_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
    int is_completed;
} Process;

int main() {
    int n;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    Process p[n];
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter arrival time of process %d: ", i + 1);
        scanf("%d", &p[i].arrival_time);
        printf("Enter burst time of process %d: ", i + 1);
        scanf("%d", &p[i].burst_time);
        p[i].is_completed = 0;
    }

    int current_time = 0, completed = 0;
    float total_tat = 0, total_wt = 0;

    printf("\nGantt Chart:\n|");

    while (completed < n) {
        int idx = -1;
        int min_burst = 100000;

        for (int i = 0; i < n; i++) {
            if (p[i].arrival_time <= current_time && !p[i].is_completed) {
                if (p[i].burst_time < min_burst) {
                    min_burst = p[i].burst_time;
                    idx = i;
                }
                if (p[i].burst_time == min_burst) {
                    if (p[i].arrival_time < p[idx].arrival_time) {
                        idx = i;
                    }
                }
            }
        }

        if (idx != -1) {
            current_time += p[idx].burst_time;
            p[idx].completion_time = current_time;
            p[idx].turnaround_time = p[idx].completion_time - p[idx].arrival_time;
            p[idx].waiting_time = p[idx].turnaround_time - p[idx].burst_time;

            p[idx].is_completed = 1;
            completed++;

            total_tat += p[idx].turnaround_time;
            total_wt += p[idx].waiting_time;

            printf(" P%d |", p[idx].pid);
        } else {
            current_time++;
        }
    }

    printf("\n\nProcess\tArrival\tBurst\tCompletion\tTurnaround\tWaiting\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t\t%d\t\t%d\n",
               p[i].pid,
               p[i].arrival_time,
               p[i].burst_time,
               p[i].completion_time,
               p[i].turnaround_time,
               p[i].waiting_time);
    }

    printf("\nAverage Turnaround Time = %.2f\n", total_tat / n);
    printf("Average Waiting Time = %.2f\n", total_wt / n);

    return 0;
}
