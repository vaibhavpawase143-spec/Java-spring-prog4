// Write a C program to implement the shell which displays the command
// prompt “myshell$”. It accepts the command, tokenize the command
// line andexecute it by creating the child process. Also implement the
// additional command „typeline‟ as
// typeline +n filename :- To print first n lines in the file.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_CMD_LEN 1024
#define MAX_ARGS 100

void typeline_plus_n(char *filename, int n) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return;
    }
    char line[1024];
    int count = 0;
    while (fgets(line, sizeof(line), fp) != NULL && count < n) {
        printf("%s", line);
        count++;
    }
    fclose(fp);
}

int main() {
    char input[MAX_CMD_LEN];
    char *args[MAX_ARGS];

    while (1) {
        printf("myshell$ ");
        if (fgets(input, sizeof(input), stdin) == NULL) {
            printf("\n");
            break;
        }
        input[strcspn(input, "\n")] = 0;
        if (strlen(input) == 0) continue;

        int i = 0;
        char *token = strtok(input, " ");
        while (token != NULL && i < MAX_ARGS - 1) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL;

        if (strcmp(args[0], "exit") == 0) break;

        if (strcmp(args[0], "typeline") == 0) {
            if (i == 3 && args[1][0] == '+') {
                int n = atoi(args[1] + 1);
                if (n <= 0) {
                    printf("Invalid number of lines\n");
                    continue;
                }
                typeline_plus_n(args[2], n);
                continue;
            } else {
                printf("Usage: typeline +n filename\n");
                continue;
            }
        }

        pid_t pid = fork();
        if (pid < 0) {
            perror("fork failed");
        } else if (pid == 0) {
            execvp(args[0], args);
            perror("command execution failed");
            exit(1);
        } else {
            wait(NULL);
        }
    }

    return 0;
}
