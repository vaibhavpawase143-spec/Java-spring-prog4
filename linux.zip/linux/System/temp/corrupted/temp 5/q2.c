// Write a program to implement the shell. It should display the command
// prompt “myshell$”. Tokenize the command line and execute the given
// command by creating the child process. Additionally it should interpret
// thefollowing commands.
// myshell$ search f filename pattern :- To display first occurrence of
// pattern in the file.
// myshell$ search c filename pattern :- To count the number of
// occurrence
// of pattern in the file.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_CMD_LEN 1024
#define MAX_ARGS 100

int search_first_occurrence(char *filename, char *pattern) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return -1;
    }
    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        char *pos = strstr(line, pattern);
        if (pos != NULL) {
            printf("First occurrence: %s", line);
            fclose(fp);
            return 0;
        }
    }
    printf("Pattern not found.\n");
    fclose(fp);
    return 0;
}

int count_pattern_occurrences(char *filename, char *pattern) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return -1;
    }
    char line[1024];
    int count = 0;
    size_t pat_len = strlen(pattern);
    while (fgets(line, sizeof(line), fp)) {
        char *ptr = line;
        while ((ptr = strstr(ptr, pattern)) != NULL) {
            count++;
            ptr += pat_len;
        }
    }
    fclose(fp);
    printf("Total occurrences: %d\n", count);
    return 0;
}

int main() {
    char input[MAX_CMD_LEN];
    char *args[MAX_ARGS];

    while (1) {
        printf("myshell$ ");
        if (fgets(input, sizeof(input), stdin) == NULL) {
            printf("\n");
            break;
        }
        input[strcspn(input, "\n")] = 0;
        if (strlen(input) == 0) continue;

        int i = 0;
        char *token = strtok(input, " ");
        while (token != NULL && i < MAX_ARGS - 1) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL;

        if (strcmp(args[0], "exit") == 0) break;

        if (strcmp(args[0], "search") == 0) {
            if (i == 4 && strcmp(args[1], "f") == 0) {
                search_first_occurrence(args[2], args[3]);
                continue;
            }
            else if (i == 4 && strcmp(args[1], "c") == 0) {
                count_pattern_occurrences(args[2], args[3]);
                continue;
            }
            else {
                printf("Usage:\nsearch f filename pattern\nsearch c filename pattern\n");
                continue;
            }
        }

        pid_t pid = fork();
        if (pid < 0) {
            perror("fork failed");
        } else if (pid == 0) {
            execvp(args[0], args);
            perror("command execution failed");
            exit(1);
        } else {
            wait(NULL);
        }
    }

    return 0;
}
