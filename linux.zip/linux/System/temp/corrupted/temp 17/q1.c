// Write the simulation program for demand paging and show the page
// scheduling and total number of page faults according the Optimal page
// replacement algorithm. Assume the memory of n frames.
// Reference String : 7, 5, 4, 8, 5, 7, 2, 3, 1, 3, 5, 9, 4, 6,

#include <stdio.h>

int search(int frame[], int n, int page) {
    for (int i = 0; i < n; i++) {
        if (frame[i] == page)
            return 1;
    }
    return 0;
}

int predict(int pages[], int frame[], int n, int index, int len) {
    int res = -1, farthest = index;
    for (int i = 0; i < n; i++) {
        int j;
        for (j = index; j < len; j++) {
            if (frame[i] == pages[j]) {
                if (j > farthest) {
                    farthest = j;
                    res = i;
                }
                break;
            }
        }
        if (j == len)
            return i;
    }
    return (res == -1) ? 0 : res;
}

int main() {
    int pages[] = {7, 5, 4, 8, 5, 7, 2, 3, 1, 3, 5, 9, 4, 6};
    int len = sizeof(pages) / sizeof(pages[0]);
    int n;

    printf("Enter number of frames: ");
    scanf("%d", &n);

    int frame[n];
    for (int i = 0; i < n; i++)
        frame[i] = -1;

    int page_faults = 0;

    printf("\nPage Scheduling:\n");

    for (int i = 0; i < len; i++) {
        printf("Page %d -> ", pages[i]);

        if (search(frame, n, pages[i])) {
            printf("Hit\n");
            continue;
        }

        page_faults++;

        int j;
        for (j = 0; j < n; j++) {
            if (frame[j] == -1) {
                frame[j] = pages[i];
                break;
            }
        }

        if (j == n) {
            int pos = predict(pages, frame, n, i + 1, len);
            frame[pos] = pages[i];
        }

        for (int k = 0; k < n; k++) {
            if (frame[k] != -1)
                printf("%d ", frame[k]);
            else
                printf("- ");
        }
        printf("\n");
    }

    printf("\nTotal Page Faults: %d\n", page_faults);

    return 0;
}
