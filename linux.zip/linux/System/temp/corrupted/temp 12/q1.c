// Write the simulation program for demand paging and show the page
// scheduling and total number of page faults according the OPT page
// replacement algorithm. Assume the memory of n frames.
// Reference String : 3, 4, 5, 6, 3, 4, 7, 3, 4, 5, 6, 7, 2, 4, 6

#include <stdio.h>

int findOptimal(int frames[], int n, int ref_str[], int len, int index) {
    int res = -1, farthest = index;
    for (int i = 0; i < n; i++) {
        int j;
        for (j = index; j < len; j++) {
            if (frames[i] == ref_str[j]) {
                if (j > farthest) {
                    farthest = j;
                    res = i;
                }
                break;
            }
        }
        if (j == len)  
            return i;
    }
    return (res == -1) ? 0 : res;
}

int main() {
    int n;
    int ref_str[] = {3, 4, 5, 6, 3, 4, 7, 3, 4, 5, 6, 7, 2, 4, 6};
    int len = sizeof(ref_str) / sizeof(ref_str[0]);

    printf("Enter number of frames: ");
    scanf("%d", &n);

    int frames[n];
    for (int i = 0; i < n; i++) frames[i] = -1;

    int page_faults = 0;

    printf("\nPage Reference\tFrames\n");
    for (int i = 0; i < len; i++) {
        int page = ref_str[i];
        int found = 0;
        for (int j = 0; j < n; j++) {
            if (frames[j] == page) {
                found = 1;
                break;
            }
        }

        if (!found) {
            page_faults++;
            int replace_index = -1;
            for (int j = 0; j < n; j++) {
                if (frames[j] == -1) {
                    replace_index = j;
                    break;
                }
            }
            if (replace_index == -1)
                replace_index = findOptimal(frames, n, ref_str, len, i + 1);

            frames[replace_index] = page;
        }

        printf("%d\t\t", page);
        for (int j = 0; j < n; j++) {
            if (frames[j] != -1) printf("%d ", frames[j]);
            else printf("- ");
        }
        printf("\n");
    }

    printf("\nTotal Page Faults = %d\n", page_faults);

    return 0;
}
