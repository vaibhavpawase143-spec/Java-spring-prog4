// Write a program to implement the toy shell. It should display the
// command prompt “myshell$”. Tokenize the command line and execute
// the given command by creating the child process. Additionally it should
// interpret thefollowing commands.
// count c filename:- To print number of characters in the file.
// count w filename:- To print number of words in the file.
// count l filename :- To print number of lines in the file.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <ctype.h>

#define MAX_CMD_LEN 1024
#define MAX_ARGS 100

int count_chars(char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return -1;
    }
    int count = 0;
    int ch;
    while ((ch = fgetc(fp)) != EOF) count++;
    fclose(fp);
    return count;
}

int count_words(char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return -1;
    }
    int count = 0;
    int in_word = 0;
    int ch;
    while ((ch = fgetc(fp)) != EOF) {
        if (isspace(ch)) {
            if (in_word) {
                count++;
                in_word = 0;
            }
        } else {
            in_word = 1;
        }
    }
    if (in_word) count++;
    fclose(fp);
    return count;
}

int count_lines(char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return -1;
    }
    int count = 0;
    char line[1024];
    while (fgets(line, sizeof(line), fp) != NULL) count++;
    fclose(fp);
    return count;
}

int main() {
    char input[MAX_CMD_LEN];
    char *args[MAX_ARGS];

    while (1) {
        printf("myshell$ ");
        if (fgets(input, sizeof(input), stdin) == NULL) {
            printf("\n");
            break;
        }
        input[strcspn(input, "\n")] = 0;
        if (strlen(input) == 0) continue;

        int i = 0;
        char *token = strtok(input, " ");
        while (token != NULL && i < MAX_ARGS - 1) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL;

        if (strcmp(args[0], "exit") == 0) break;

        if (strcmp(args[0], "count") == 0) {
            if (i == 3) {
                if (strcmp(args[1], "c") == 0) {
                    int res = count_chars(args[2]);
                    if (res >= 0)
                        printf("Characters: %d\n", res);
                } else if (strcmp(args[1], "w") == 0) {
                    int res = count_words(args[2]);
                    if (res >= 0)
                        printf("Words: %d\n", res);
                } else if (strcmp(args[1], "l") == 0) {
                    int res = count_lines(args[2]);
                    if (res >= 0)
                        printf("Lines: %d\n", res);
                } else {
                    printf("Invalid count option. Use c, w, or l.\n");
                }
                continue;
            } else {
                printf("Usage: count c filename\n       count w filename\n       count l filename\n");
                continue;
            }
        }

        pid_t pid = fork();
        if (pid < 0) {
            perror("fork failed");
        } else if (pid == 0) {
            execvp(args[0], args);
            perror("command execution failed");
            exit(1);
        } else {
            wait(NULL);
        }
    }
    return 0;
}
