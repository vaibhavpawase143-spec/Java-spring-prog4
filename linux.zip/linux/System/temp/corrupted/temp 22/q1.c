//  Write a C program that demonstrates the use of nice() system call. After a
// child Process is started using fork (), assign higher priority to the child
// usingnice () system call.

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/resource.h> // for nice()
#include <stdlib.h>

int main() {
    pid_t pid;

    pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        return 1;
    }

    else if (pid == 0) {
        // Child process
        printf("Child: My PID is %d\n", getpid());

        int old_nice = getpriority(PRIO_PROCESS, 0);
        printf("Child: Old nice value = %d\n", old_nice);

        int new_nice = nice(-5);  // try to increase priority

        if (new_nice == -1 && errno != 0) {
            perror("Child: nice() failed");
        } else {
            printf("Child: New nice value = %d\n", getpriority(PRIO_PROCESS, 0));
        }

        printf("Child: I am running with higher priority (if permitted).\n");
    }

    else {
        // Parent process
        int status;
        printf("Parent: My PID is %d\n", getpid());

        int parent_nice = getpriority(PRIO_PROCESS, 0);
        printf("Parent: Nice value = %d\n", parent_nice);

        wait(&status); // Wait for child to finish
        printf("Parent: Child finished execution.\n");
    }

    return 0;
}
