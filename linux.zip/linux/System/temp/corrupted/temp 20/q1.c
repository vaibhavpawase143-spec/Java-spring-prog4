// Write a C program to implement the shell which displays the command
// prompt “myshell$”. It accepts the command, tokenize the command line
// and execute it by creating the child process. Also implement the
// additional command „typeline‟ as
// typeline -a filename :- To print all lines in the file.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_CMD_LEN 1024
#define MAX_ARGS 100

// Function to handle custom "typeline -a filename" command
void typeline_all(const char *filename) {
    FILE *fp = fopen(filename, "r");

    if (fp == NULL) {
        perror("Cannot open file");
        return;
    }

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        printf("%s", line); // Print each line
    }

    fclose(fp);
}

// Function to execute normal commands
void execute_command(char *args[]) {
    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
    } else if (pid == 0) {
        // In child process
        if (execvp(args[0], args) == -1) {
            perror("Command execution failed");
        }
        exit(EXIT_FAILURE);
    } else {
        // In parent process
        wait(NULL);
    }
}

int main() {
    char input[MAX_CMD_LEN];
    char *args[MAX_ARGS];

    while (1) {
        printf("myshell$ ");
        fflush(stdout);

        if (fgets(input, sizeof(input), stdin) == NULL)
            break;

        // Remove newline at end
        input[strcspn(input, "\n")] = '\0';

        // Exit command
        if (strcmp(input, "exit") == 0)
            break;

        // Tokenize input
        int i = 0;
        char *token = strtok(input, " ");
        while (token != NULL && i < MAX_ARGS - 1) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL;

        // Handle custom "typeline -a filename"
        if (i == 3 && strcmp(args[0], "typeline") == 0 && strcmp(args[1], "-a") == 0) {
            typeline_all(args[2]);
        } else if (args[0] != NULL) {
            // Handle normal Linux commands
            execute_command(args);
        }
    }

    return 0;
}
