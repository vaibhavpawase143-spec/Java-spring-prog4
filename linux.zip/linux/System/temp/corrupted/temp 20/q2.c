// Write the program to simulate preemptive Shortest Job First (SJF) –
// scheduling. The arrival time and first CPU-burst of different jobs
// should be input to the system. Accept no. of Processes, arrival time and
// burst time. The output should give Gantt chart, turnaround time and
// waiting time for each process. Also find the average waiting time and
// turnaround

#include <stdio.h>

struct Process {
    int pid;
    int arrival;
    int burst;
    int remaining;
    int completion;
    int waiting;
    int turnaround;
};

int main() {
    int n, completed = 0, time = 0, min_index;
    float totalWT = 0, totalTAT = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process p[n];

    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter Arrival Time for Process P%d: ", p[i].pid);
        scanf("%d", &p[i].arrival);
        printf("Enter Burst Time for Process P%d: ", p[i].pid);
        scanf("%d", &p[i].burst);
        p[i].remaining = p[i].burst;
    }

    int prev = -1;
    printf("\nGantt Chart:\n");
    printf("|");

    while (completed != n) {
        min_index = -1;
        int min_remaining = 99999;

        for (int i = 0; i < n; i++) {
            if (p[i].arrival <= time && p[i].remaining > 0 && p[i].remaining < min_remaining) {
                min_remaining = p[i].remaining;
                min_index = i;
            }
        }

        if (min_index != -1) {
            if (prev != min_index) {
                printf(" P%d |", p[min_index].pid);
                prev = min_index;
            }

            p[min_index].remaining--;
            time++;

            if (p[min_index].remaining == 0) {
                p[min_index].completion = time;
                completed++;
            }
        } else {
            // CPU Idle
            if (prev != -2) {
                printf(" IDLE |");
                prev = -2;
            }
            time++;
        }
    }

    // Calculate TAT and WT
    for (int i = 0; i < n; i++) {
        p[i].turnaround = p[i].completion - p[i].arrival;
        p[i].waiting = p[i].turnaround - p[i].burst;
        totalWT += p[i].waiting;
        totalTAT += p[i].turnaround;
    }

    // Print time under Gantt chart (simple approach)
    printf("\n");

    // Print Table
    printf("\nProcess\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n",
               p[i].pid,
               p[i].arrival,
               p[i].burst,
               p[i].completion,
               p[i].turnaround,
               p[i].waiting);
    }

    printf("\nAverage Waiting Time: %.2f\n", totalWT / n);
    printf("Average Turnaround Time: %.2f\n", totalTAT / n);

    return 0;
}
