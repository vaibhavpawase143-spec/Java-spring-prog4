// Write a C program to simulate FCFS scheduling. Thearrival time and
// first CPU-burst of different jobs should be input to the system. Accept no.
// of Processes, arrival time and burst time. The output should give Gantt
// chart, turnaround time and waiting time for each process. Also find the
// average waiting time and turnaround time.


#include <stdio.h>

int main() {
    int n, i;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    int arrival[n], burst[n], start[n], completion[n], tat[n], wt[n];
    int time = 0;

    // Input arrival time and burst time
    for (i = 0; i < n; i++) {
        printf("Enter arrival time of process P%d: ", i + 1);
        scanf("%d", &arrival[i]);
        printf("Enter burst time of process P%d: ", i + 1);
        scanf("%d", &burst[i]);
    }

    // FCFS Scheduling
    for (i = 0; i < n; i++) {
        if (time < arrival[i]) {
            time = arrival[i]; // CPU idle till arrival
        }
        start[i] = time;
        completion[i] = start[i] + burst[i];
        time = completion[i];
        tat[i] = completion[i] - arrival[i];       // Turnaround time
        wt[i] = tat[i] - burst[i];                 // Waiting time
    }

    // Print Gantt chart
    printf("\nGantt Chart:\n|");
    for (i = 0; i < n; i++) {
        printf(" P%d |", i + 1);
    }
    printf("\n");

    printf("0");
    for (i = 0; i < n; i++) {
        printf("    %d", completion[i]);
    }
    printf("\n");

    // Print process details
    printf("\nProcess\tArrival\tBurst\tCompletion\tTurnaround\tWaiting\n");
    float total_tat = 0, total_wt = 0;
    for (i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t\t%d\t\t%d\n", 
                i + 1, arrival[i], burst[i], completion[i], tat[i], wt[i]);
        total_tat += tat[i];
        total_wt += wt[i];
    }

    printf("\nAverage Turnaround Time = %.2f\n", total_tat / n);
    printf("Average Waiting Time = %.2f\n", total_wt / n);

    return 0;
}
