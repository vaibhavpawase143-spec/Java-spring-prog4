// Write a C program to illustrate the concept of orphan process. Parent
// processcreates a child and terminates before child has finished its task. So
// child process becomes orphan process. (Use fork(), sleep(), getpid(),
// getppid()).


#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        return 1;
    }

    if (pid == 0) {
        // Child process
        printf("Child: My PID is %d\n", getpid());
        printf("Child: My parent PID before sleep is %d\n", getppid());
        
        sleep(5);  // Sleep to allow parent to terminate
        
        printf("Child: My parent PID after sleep is %d\n", getppid());
        printf("Child: I am now an orphan process, adopted by init/systemd.\n");
    } else {
        // Parent process
        printf("Parent: My PID is %d\n", getpid());
        printf("Parent: I am terminating now.\n");
        exit(0);  // Parent terminates immediately
    }

    return 0;
}
