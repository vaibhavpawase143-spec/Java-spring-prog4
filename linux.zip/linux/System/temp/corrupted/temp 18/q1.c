// Write the simulation program for demand paging and show the page
// scheduling and total number of page faults according the LRU page
// replacement algorithm. Assume the memory of n frames.
// Reference String : 3, 4, 5, 6, 3, 4, 7, 3, 4, 5, 6, 7, 2, 4, 6

#include <stdio.h>

#define REFERENCE_STRING_LENGTH 15

int findLRU(int time[], int n) {
    int i, minimum = time[0], pos = 0;

    for(i = 1; i < n; ++i) {
        if(time[i] < minimum) {
            minimum = time[i];
            pos = i;
        }
    }

    return pos;
}

int main() {
    int frames, pages[REFERENCE_STRING_LENGTH] = {3, 4, 5, 6, 3, 4, 7, 3, 4, 5, 6, 7, 2, 4, 6};
    int temp[50], time[50];
    int i, j, pos, flag1, flag2, pageFaults = 0;
    int counter = 0;

    printf("Enter number of frames: ");
    scanf("%d", &frames);

    for(i = 0; i < frames; ++i) {
        temp[i] = -1; // Initialize all frames to empty
    }

    printf("\nPage Reference\tFrames\n");

    for(i = 0; i < REFERENCE_STRING_LENGTH; ++i) {
        flag1 = flag2 = 0;

        // Check if page is already in frame
        for(j = 0; j < frames; ++j) {
            if(temp[j] == pages[i]) {
                counter++;
                time[j] = counter;
                flag1 = flag2 = 1;
                break;
            }
        }

        // If page not found
        if(flag1 == 0) {
            for(j = 0; j < frames; ++j) {
                if(temp[j] == -1) {
                    counter++;
                    pageFaults++;
                    temp[j] = pages[i];
                    time[j] = counter;
                    flag2 = 1;
                    break;
                }
            }
        }

        // Replace LRU page
        if(flag2 == 0) {
            pos = findLRU(time, frames);
            counter++;
            pageFaults++;
            temp[pos] = pages[i];
            time[pos] = counter;
        }

        // Print current frame state
        printf("%d\t\t", pages[i]);
        for(j = 0; j < frames; ++j) {
            if(temp[j] != -1)
                printf("%d ", temp[j]);
            else
                printf("- ");
        }
        printf("\n");
    }

    printf("\nTotal Page Faults = %d\n", pageFaults);

    return 0;
}
