// Write a C program to simulate FCFS CPU-scheduling. The arrival time
// and first CPU-burst of different jobs should be input to the system.
// Accept no. ofProcesses, arrival time and burst time. The output should
// give Gantt chart, turnaround time and waiting time for each process.
// Also find the average waiting time and turnaround time.

#include <stdio.h>

struct Process {
    int pid;        // Process ID
    int arrival;    // Arrival Time
    int burst;      // Burst Time
    int start;      // Start Time
    int finish;     // Completion Time
    int waiting;    // Waiting Time
    int turnaround; // Turnaround Time
};

int main() {
    int n, i;
    float totalWT = 0, totalTAT = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process p[n];

    // Input arrival and burst times
    for (i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter Arrival Time for Process P%d: ", p[i].pid);
        scanf("%d", &p[i].arrival);
        printf("Enter Burst Time for Process P%d: ", p[i].pid);
        scanf("%d", &p[i].burst);
    }

    // Sort processes by arrival time (FCFS)
    for (i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (p[j].arrival > p[j + 1].arrival) {
                struct Process temp = p[j];
                p[j] = p[j + 1];
                p[j + 1] = temp;
            }
        }
    }

    // Calculate start time, finish time, waiting time, turnaround time
    int currentTime = 0;
    for (i = 0; i < n; i++) {
        if (currentTime < p[i].arrival)
            currentTime = p[i].arrival;

        p[i].start = currentTime;
        p[i].waiting = p[i].start - p[i].arrival;
        p[i].finish = p[i].start + p[i].burst;
        p[i].turnaround = p[i].finish - p[i].arrival;

        currentTime = p[i].finish;

        totalWT += p[i].waiting;
        totalTAT += p[i].turnaround;
    }

    // Print Gantt Chart
    printf("\nGantt Chart:\n|");
    for (i = 0; i < n; i++) {
        printf(" P%d |", p[i].pid);
    }

    // Print times under Gantt Chart
    printf("\n0");
    for (i = 0; i < n; i++) {
        printf("   %d", p[i].finish);
    }

    // Print process table
    printf("\n\nProcess\tAT\tBT\tST\tCT\tWT\tTAT\n");
    for (i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
               p[i].pid, p[i].arrival, p[i].burst,
               p[i].start, p[i].finish,
               p[i].waiting, p[i].turnaround);
    }

    printf("\nAverage Waiting Time: %.2f", totalWT / n);
    printf("\nAverage Turnaround Time: %.2f\n", totalTAT / n);

    return 0;
}
