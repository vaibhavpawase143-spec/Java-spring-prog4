// Write the simulation program for demand paging and show the page
// scheduling and total number of page faults according the FIFO page
// replacement algorithm. Assume the memory of n frames.
// Reference String : 3, 4, 5, 6, 3, 4, 7, 3, 4, 5, 6, 7, 2, 4, 6
#include <stdio.h>

int main() {
    int n;
    int ref_str[] = {3,4,5,6,3,4,7,3,4,5,6,7,2,4,6};
    int len = sizeof(ref_str)/sizeof(ref_str[0]);

    printf("Enter number of frames: ");
    scanf("%d", &n);

    int frames[n];
    int i, j;
    int page_faults = 0;
    int next_replace = 0;  

   
    for(i = 0; i < n; i++) {
        frames[i] = -1;
    }

    printf("\nPage Reference\tFrames\n");
    printf("----------------------------\n");

    for(i = 0; i < len; i++) {
        int page = ref_str[i];
        int found = 0;

        for(j = 0; j < n; j++) {
            if(frames[j] == page) {
                found = 1;
                break;
            }
        }

        if(!found) {
           
            frames[next_replace] = page;
            next_replace = (next_replace + 1) % n;
            page_faults++;
        }

        
        printf("%d\t\t", page);
        for(j = 0; j < n; j++) {
            if(frames[j] != -1)
                printf("%d ", frames[j]);
            else
                printf("- ");
        }
        printf("\n");
    }

    printf("\nTotal Page Faults = %d\n", page_faults);

    return 0;
}
