// Write a C program to simulate non preemptive priority scheduling. The
// arrival time and first CPU-burst of different jobs should be input to the
// system. Accept no. of Processes, arrival time and burst time. The output
// should give Gantt chart, turnaround time and waiting time for each
// process. Also find the average waiting time and turnaround time.


#include <stdio.h>

struct Process {
    int pid;
    int arrival;
    int burst;
    int priority;
    int completion;
    int turnaround;
    int waiting;
    int is_completed;
};

int main() {
    int n, time = 0, completed = 0;
    float total_TAT = 0, total_WT = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process p[n];

    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("\nEnter Arrival Time for P%d: ", p[i].pid);
        scanf("%d", &p[i].arrival);
        printf("Enter Burst Time for P%d: ", p[i].pid);
        scanf("%d", &p[i].burst);
        printf("Enter Priority for P%d (Lower number = Higher priority): ", p[i].pid);
        scanf("%d", &p[i].priority);
        p[i].is_completed = 0;
    }

    printf("\nGantt Chart:\n|");
    int prev = -1;

    while (completed < n) {
        int idx = -1;
        int highest_priority = 9999;

        for (int i = 0; i < n; i++) {
            if (p[i].arrival <= time && p[i].is_completed == 0) {
                if (p[i].priority < highest_priority ||
                    (p[i].priority == highest_priority && p[i].arrival < p[idx].arrival)) {
                    highest_priority = p[i].priority;
                    idx = i;
                }
            }
        }

        if (idx != -1) {
            p[idx].completion = time + p[idx].burst;
            p[idx].turnaround = p[idx].completion - p[idx].arrival;
            p[idx].waiting = p[idx].turnaround - p[idx].burst;
            p[idx].is_completed = 1;
            completed++;

            total_TAT += p[idx].turnaround;
            total_WT += p[idx].waiting;

            printf(" P%d |", p[idx].pid);
            time = p[idx].completion;
        } else {
            // No process is ready to execute, CPU idle
            printf(" IDLE |");
            time++;
        }
    }

    // Print Table
    printf("\n\nProcess\tAT\tBT\tPri\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
               p[i].pid, p[i].arrival, p[i].burst, p[i].priority,
               p[i].completion, p[i].turnaround, p[i].waiting);
    }

    printf("\nAverage Turnaround Time: %.2f\n", total_TAT / n);
    printf("Average Waiting Time   : %.2f\n", total_WT / n);

    return 0;
}
