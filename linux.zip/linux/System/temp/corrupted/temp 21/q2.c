// Write a C program to simulate non Preemptive Priority scheduling. The
// arrivaltime and first CPU-burst and priority for different n number of
// processes should be input to the algorithm. Assume the fixed IO waiting
// time (2 units). The next CPU-burst should be generated randomly. The
// output should give Gantt chart, turnaround time and waiting time for each
// process. Also find the average waiting time and turnaround time.

#include <stdio.h>
#include <stdlib.h>

#include <time.h>

struct Process {
    int pid;
    int arrival;
    int burst1;
    int burst2;
    int priority;
    int completion;
    int turnaround;
    int waiting;
    int start;
    int io_done_time;
    int isFirstDone;
};

void sortByArrivalAndPriority(struct Process p[], int n, int currentTime) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if ((p[j].arrival <= currentTime && p[j].isFirstDone == 0 && p[j].priority < p[i].priority) ||
                (p[i].isFirstDone == 1) ||
                (p[j].arrival < p[i].arrival && p[j].isFirstDone == 0)) {
                struct Process temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            }
        }
    }
}

int main() {
    int n;
    srand(time(NULL)); // For random BT2

    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process p[n];
    int totalBurst[n];

    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter Arrival Time for Process P%d: ", p[i].pid);
        scanf("%d", &p[i].arrival);
        printf("Enter First CPU Burst Time for Process P%d: ", p[i].pid);
        scanf("%d", &p[i].burst1);
        printf("Enter Priority (lower number = higher priority) for Process P%d: ", p[i].pid);
        scanf("%d", &p[i].priority);

        p[i].burst2 = (rand() % 5) + 1;  // Random second CPU burst between 1 to 5
        p[i].isFirstDone = 0;
        p[i].io_done_time = 0;
    }

    int completed = 0, currentTime = 0;
    printf("\nGantt Chart:\n|");

    while (completed < n) {
        int found = 0;
        sortByArrivalAndPriority(p, n, currentTime);

        for (int i = 0; i < n; i++) {
            // First CPU Burst
            if (p[i].arrival <= currentTime && p[i].isFirstDone == 0) {
                p[i].start = currentTime;
                printf(" P%d(B1) |", p[i].pid);
                currentTime += p[i].burst1;
                p[i].io_done_time = currentTime + 2; // I/O wait
                p[i].isFirstDone = 1;
                found = 1;
                break;
            }

            // Second CPU Burst after I/O
            else if (p[i].isFirstDone == 1 && p[i].io_done_time <= currentTime && p[i].burst2 > 0) {
                printf(" P%d(B2) |", p[i].pid);
                currentTime += p[i].burst2;
                p[i].completion = currentTime;
                p[i].turnaround = p[i].completion - p[i].arrival;
                p[i].waiting = p[i].turnaround - (p[i].burst1 + p[i].burst2 + 2); // include I/O
                p[i].burst2 = 0;
                completed++;
                found = 1;
                break;
            }
        }

        if (!found)
            currentTime++; // Idle CPU
    }

    // Output Table
    float totalWT = 0, totalTAT = 0;
    printf("\n\nProcess\tAT\tB1\tIO\tB2\tPri\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t2\t%d\t%d\t%d\t%d\t%d\n",
               p[i].pid, p[i].arrival, p[i].burst1, p[i].burst2,
               p[i].priority, p[i].completion, p[i].turnaround, p[i].waiting);
        totalWT += p[i].waiting;
        totalTAT += p[i].turnaround;
    }

    printf("\nAverage Waiting Time: %.2f", totalWT / n);
    printf("\nAverage Turnaround Time: %.2f\n", totalTAT / n);

    return 0;
}
