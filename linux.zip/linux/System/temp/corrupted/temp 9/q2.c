// Write a program to implement the toy shell. It should display the
// command prompt “myshell$”. Tokenize the command line and execute
// the given command by creating the child process. Additionally it should
// interpret thefollowing commands.
// count c filename:- To print number of characters in the file.
// count w filename:- To print number of words in the file.
// count l filename :- To print number of lines in the file.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_CMD_LEN 1024
#define MAX_ARGS 100

void count_chars(char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return;
    }
    int count = 0;
    int c;
    while ((c = fgetc(fp)) != EOF) {
        count++;
    }
    fclose(fp);
    printf("Number of characters: %d\n", count);
}

void count_words(char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return;
    }
    int count = 0;
    char word[256];
    while (fscanf(fp, "%255s", word) == 1) {
        count++;
    }
    fclose(fp);
    printf("Number of words: %d\n", count);
}

void count_lines(char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("File open error");
        return;
    }
    int count = 0;
    char line[1024];
    while (fgets(line, sizeof(line), fp) != NULL) {
        count++;
    }
    fclose(fp);
    printf("Number of lines: %d\n", count);
}

int main() {
    char input[MAX_CMD_LEN];
    char *args[MAX_ARGS];

    while (1) {
        printf("myshell$ ");
        if (fgets(input, sizeof(input), stdin) == NULL) {
            printf("\n");
            break;
        }
        input[strcspn(input, "\n")] = 0;
        if (strlen(input) == 0) continue;

        int i = 0;
        char *token = strtok(input, " ");
        while (token != NULL && i < MAX_ARGS - 1) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL;

        if (strcmp(args[0], "exit") == 0) break;

        if (strcmp(args[0], "count") == 0) {
            if (i == 3) {
                if (strcmp(args[1], "c") == 0) {
                    count_chars(args[2]);
                    continue;
                }
                else if (strcmp(args[1], "w") == 0) {
                    count_words(args[2]);
                    continue;
                }
                else if (strcmp(args[1], "l") == 0) {
                    count_lines(args[2]);
                    continue;
                }
            }
            printf("Usage:\ncount c filename\ncount w filename\ncount l filename\n");
            continue;
        }

        pid_t pid = fork();
        if (pid < 0) {
            perror("fork failed");
        } else if (pid == 0) {
            execvp(args[0], args);
            perror("command execution failed");
            exit(1);
        } else {
            wait(NULL);
        }
    }
    return 0;
}
