// Write the simulation program for demand paging and show the page
// scheduling and total number of page faults according the FIFO page
// replacement algorithm. Assume the memory of n frames.
// Reference String : 8, 5, 7, 8, 5, 7, 2, 3, 7, 3, 5, 9, 4, 6, 2

#include <stdio.h>

int main() {
    int n;
    int ref_str[] = {8, 5, 7, 8, 5, 7, 2, 3, 7, 3, 5, 9, 4, 6, 2};
    int len = sizeof(ref_str) / sizeof(ref_str[0]);

    printf("Enter number of frames: ");
    scanf("%d", &n);

    int frames[n];
    int i, j;
    int page_faults = 0, front = 0;

    for (i = 0; i < n; i++)
        frames[i] = -1;

    printf("\nPage Reference\tFrames\n");

    for (i = 0; i < len; i++) {
        int page = ref_str[i];
        int found = 0;

        for (j = 0; j < n; j++) {
            if (frames[j] == page) {
                found = 1;
                break;
            }
        }

        if (!found) {
            frames[front] = page;
            front = (front + 1) % n;
            page_faults++;
        }

        printf("%d\t\t", page);
        for (j = 0; j < n; j++) {
            if (frames[j] != -1)
                printf("%d ", frames[j]);
            else
                printf("- ");
        }
        printf("\n");
    }

    printf("\nTotal Page Faults = %d\n", page_faults);

    return 0;
}
