import java.io.*;

public class DisplayFileContent {
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java DisplayFileContent <filename>");
            return;
        }

        String filename = args[0];

        try {
            File file = new File(filename);
            if (!file.exists()) {
                System.out.println("File not found: " + filename);
                return;
            }

            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            System.out.println("Content of file '" + filename + "':\n");

            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }

            br.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}
