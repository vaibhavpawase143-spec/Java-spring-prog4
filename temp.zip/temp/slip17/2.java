import java.util.Scanner;

class Employee {
    int empid;
    String empname;
    double salary;

    void accept() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Employee ID: ");
        empid = sc.nextInt();
        sc.nextLine(); 
        System.out.print("Enter Employee Name: ");
        empname = sc.nextLine();
        System.out.print("Enter Salary: ");
        salary = sc.nextDouble();
    }

    void display() {
        System.out.printf("%-10d %-15s %-10.2f\n", empid, empname, salary);
    }

    static void sortEmployee(Employee[] empArr) {
        for (int i = 0; i < empArr.length - 1; i++) {
            for (int j = i + 1; j < empArr.length; j++) {
                if (empArr[i].salary > empArr[j].salary) {
                    Employee temp = empArr[i];
                    empArr[i] = empArr[j];
                    empArr[j] = temp;
                }
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of employees: ");
        int n = sc.nextInt();

        Employee[] empArr = new Employee[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Employee " + (i + 1) + ":");
            empArr[i] = new Employee();
            empArr[i].accept();
        }

        Employee.sortEmployee(empArr);

        System.out.println("\n--- Employee Details Sorted by Salary (Ascending) ---");
        System.out.printf("%-10s %-15s %-10s\n", "EmpID", "Name", "Salary");
        System.out.println("----------------------------------------------");

        for (Employee e : empArr) {
            e.display();
        }
    }
}
