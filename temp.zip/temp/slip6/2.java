import java.util.Scanner;

abstract class Staff {
    protected int id;
    protected String name;

    Staff(int id, String name) {
        this.id = id;
        this.name = name;
    }

    abstract void displayDetails();
}

class OfficeStaff extends Staff {
    private String department;

    OfficeStaff(int id, String name, String department) {
        super(id, name); 
        this.department = department;
    }


    void displayDetails() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Department: " + department);
        System.out.println("----------------------");
    }
}

public class StaffMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of Office Staff: ");
        int n = sc.nextInt();
        sc.nextLine();

        OfficeStaff[] staffArr = new OfficeStaff[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for staff " + (i + 1));

            System.out.print("Enter ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            System.out.print("Enter Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Department: ");
            String dept = sc.nextLine();

            staffArr[i] = new OfficeStaff(id, name, dept);
        }

        System.out.println ("\n--- Office Staff Details ---");
        for (int i = 0; i < n; i++) {
            staffArr[i].displayDetails();
        }

        sc.close();
    }
}
