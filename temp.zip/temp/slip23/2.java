import java.util.Scanner;

public class MatrixOperations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Matrix Operations Menu ---");
            System.out.println("1. Addition of two matrices");
            System.out.println("2. Multiplication of two matrices");
            System.out.println("3. Transpose of a matrix");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter number of rows: ");
                    int rows1 = sc.nextInt();
                    System.out.print("Enter number of columns: ");
                    int cols1 = sc.nextInt();

                    int[][] mat1 = new int[rows1][cols1];
                    int[][] mat2 = new int[rows1][cols1];

                    System.out.println("Enter elements of first matrix:");
                    for (int i = 0; i < rows1; i++)
                        for (int j = 0; j < cols1; j++)
                            mat1[i][j] = sc.nextInt();

                    System.out.println("Enter elements of second matrix:");
                    for (int i = 0; i < rows1; i++)
                        for (int j = 0; j < cols1; j++)
                            mat2[i][j] = sc.nextInt();

                    int[][] sum = new int[rows1][cols1];
                    for (int i = 0; i < rows1; i++)
                        for (int j = 0; j < cols1; j++)
                            sum[i][j] = mat1[i][j] + mat2[i][j];

                    System.out.println("Sum of matrices:");
                    printMatrix(sum);
                    break;

                case 2:
                    System.out.print("Enter rows of first matrix: ");
                    int r1 = sc.nextInt();
                    System.out.print("Enter columns of first matrix: ");
                    int c1 = sc.nextInt();

                    System.out.print("Enter rows of second matrix: ");
                    int r2 = sc.nextInt();
                    System.out.print("Enter columns of second matrix: ");
                    int c2 = sc.nextInt();

                    if (c1 != r2) {
                        System.out.println("Matrix multiplication not possible! Columns of first matrix must equal rows of second matrix.");
                        break;
                    }

                    int[][] a = new int[r1][c1];
                    int[][] b = new int[r2][c2];

                    System.out.println("Enter elements of first matrix:");
                    for (int i = 0; i < r1; i++)
                        for (int j = 0; j < c1; j++)
                            a[i][j] = sc.nextInt();

                    System.out.println("Enter elements of second matrix:");
                    for (int i = 0; i < r2; i++)
                        for (int j = 0; j < c2; j++)
                            b[i][j] = sc.nextInt();

                    int[][] product = new int[r1][c2];

                    for (int i = 0; i < r1; i++) {
                        for (int j = 0; j < c2; j++) {
                            for (int k = 0; k < c1; k++) {
                                product[i][j] += a[i][k] * b[k][j];
                            }
                        }
                    }

                    System.out.println("Product of matrices:");
                    printMatrix(product);
                    break;

                case 3:
                    System.out.print("Enter number of rows: ");
                    int rows = sc.nextInt();
                    System.out.print("Enter number of columns: ");
                    int cols = sc.nextInt();

                    int[][] mat = new int[rows][cols];
                    System.out.println("Enter elements of matrix:");
                    for (int i = 0; i < rows; i++)
                        for (int j = 0; j < cols; j++)
                            mat[i][j] = sc.nextInt();

                    int[][] transpose = new int[cols][rows];
                    for (int i = 0; i < rows; i++)
                        for (int j = 0; j < cols; j++)
                            transpose[j][i] = mat[i][j];

                    System.out.println("Transpose of matrix:");
                    printMatrix(transpose);
                    break;

                case 4:
                    System.out.println("Exiting program...");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 4);
    }

    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int val : row)
                System.out.print(val + "\t");
            System.out.println();
        }
    }
}
