import java.util.Scanner;

interface Operation {
    double PI = 3.142;

    double area(); 
    double volume(); 
}

class Cylinder implements Operation {
    private double radius;
    private double height;

    Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

    @Override
    public double area() {
        return 2 * PI * radius * (radius + height);
    }

    @Override
    public double volume() {
        return PI * radius * radius * height;
    }
}

public class CylinderOperation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter radius of cylinder: ");
        double r = sc.nextDouble();

        System.out.print("Enter height of cylinder: ");
        double h = sc.nextDouble();

        Cylinder cyl = new Cylinder(r, h);

        System.out.printf("Surface Area of Cylinder: %.2f\n", cyl.area());
        System.out.printf("Volume of Cylinder: %.2f\n", cyl.volume());

        sc.close();
    }
}
