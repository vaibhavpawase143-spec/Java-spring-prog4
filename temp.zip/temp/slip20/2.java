import java.util.Scanner;

public class MenuDrivenProgram {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Menu ---");
            System.out.println("1. Calculate volume of cylinder");
            System.out.println("2. Find factorial of a number");
            System.out.println("3. Check if a number is Armstrong");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter radius of cylinder: ");
                    double r = sc.nextDouble();
                    System.out.print("Enter height of cylinder: ");
                    double h = sc.nextDouble();
                    double volume = Math.PI * r * r * h;
                    System.out.printf("Volume of cylinder = %.2f\n", volume);
                    break;

                case 2:
                    System.out.print("Enter a number: ");
                    int num = sc.nextInt();
                    long fact = 1;
                    for (int i = 1; i <= num; i++) {
                        fact *= i;
                    }
                    System.out.println("Factorial of " + num + " = " + fact);
                    break;

                case 3:
                    System.out.print("Enter a number: ");
                    int number = sc.nextInt();
                    int sum = 0, temp = number;
                    int digits = String.valueOf(number).length();
                    while (temp != 0) {
                        int rem = temp % 10;
                        sum += Math.pow(rem, digits);
                        temp /= 10;
                    }
                    if (sum == number)
                        System.out.println(number + " is an Armstrong number.");
                    else
                        System.out.println(number + " is not an Armstrong number.");
                    break;

                case 4:
                    System.out.println("Exiting program...");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }
        } while (choice != 4);
    }
}
