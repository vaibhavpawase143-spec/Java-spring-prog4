import java.util.Scanner;

interface Operation {
    double PI = 3.142;
    
    double area();
    double volume();
}

class Cylinder implements Operation {
    double radius, height;
    
    Cylinder(double r, double h) {
        radius = r;
        height = h;
    }
    
    public double area() {
        return 2 * PI * radius * (radius + height);
    }
    
    public double volume() {
        return PI * radius * radius * height;
    }
}

public class SimpleCylinder {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter radius: ");
        double r = sc.nextDouble();
        
        System.out.print("Enter height: ");
        double h = sc.nextDouble();
        
        Cylinder c = new Cylinder(r, h);
        
        System.out.println("Area = " + c.area());
        System.out.println("Volume = " + c.volume());
        
        sc.close();
    }
}
