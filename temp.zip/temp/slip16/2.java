import java.util.Scanner;

class CricketPlayer {
    String name;
    int no_of_innings;
    int no_of_times_notout;
    int total_runs;
    double bat_avg;

    void accept() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter player name: ");
        name = sc.nextLine();
        System.out.print("Enter number of innings: ");
        no_of_innings = sc.nextInt();
        System.out.print("Enter number of times not out: ");
        no_of_times_notout = sc.nextInt();
        System.out.print("Enter total runs: ");
        total_runs = sc.nextInt();
    }

    static void avg(CricketPlayer[] players) {
        for (CricketPlayer p : players) {
            int outs = p.no_of_innings - p.no_of_times_notout;
            if (outs != 0)
                p.bat_avg = (double) p.total_runs / outs;
            else
                p.bat_avg = p.total_runs; 
        }
    }

    static void sort(CricketPlayer[] players) {
        for (int i = 0; i < players.length - 1; i++) {
            for (int j = i + 1; j < players.length; j++) {
                if (players[i].bat_avg < players[j].bat_avg) {
                    CricketPlayer temp = players[i];
                    players[i] = players[j];
                    players[j] = temp;
                }
            }
        }
    }

    void display() {
        System.out.printf("%-15s %-10d %-15d %-12d %-10.2f\n",
                name, no_of_innings, no_of_times_notout, total_runs, bat_avg);
    }
}


public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of players: ");
        int n = sc.nextInt();
        sc.nextLine(); 
        CricketPlayer[] players = new CricketPlayer[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for player " + (i + 1) + ":");
            players[i] = new CricketPlayer();
            players[i].accept();
        }

        CricketPlayer.avg(players);

        CricketPlayer.sort(players);

        System.out.println("\n--- Player Details (Sorted by Batting Average) ---");
        System.out.printf("%-15s %-10s %-15s %-12s %-10s\n",
                "Name", "Innings", "Not Out", "Total Runs", "Average");
        System.out.println("-------------------------------------------------------------");
        for (CricketPlayer p : players) {
            p.display();
        }
    }
}
