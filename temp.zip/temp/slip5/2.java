import java.util.Scanner;

interface ProductMarker {

}

class Product implements ProductMarker {
    int product_id;
    String product_name;
    double product_cost;
    int product_quantity;

    static int count = 0;

    Product() {
        product_id = 0;
        product_name = "N/A";
        product_cost = 0.0;
        product_quantity = 0;
        count++;
    }

    Product(int id, String name, double cost, int qty) {
        product_id = id;
        product_name = name;
        product_cost = cost;
        product_quantity = qty;
        count++;
    }

    void display() {
        System.out.println("\n--- Product Details ---");
        System.out.println("Product ID      : " + product_id);
        System.out.println("Product Name    : " + product_name);
        System.out.println("Product Cost    : " + product_cost);
        System.out.println("Product Quantity: " + product_quantity);
    }
}

public class ProductDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of products: ");
        int n = sc.nextInt();
        sc.nextLine();

        Product[] products = new Product[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Product " + (i + 1) + ":");

            System.out.print("Product ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            System.out.print("Product Name: ");
            String name = sc.nextLine();

            System.out.print("Product Cost: ");
            double cost = sc.nextDouble();

            System.out.print("Product Quantity: ");
            int qty = sc.nextInt();
            sc.nextLine();

            products[i] = new Product(id, name, cost, qty);
        }

        System.out.println("\n=== All Products ===");
        for (int i = 0; i < n; i++) {
            products[i].display();
        }
        System.out.println("\nTotal Product Objects Created: " + Product.count);

        sc.close();
    }
}
