import java.util.Scanner;

class Student {
    int rollno;
    String name;
    String className;
    double per;

    void Student() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Roll Number: ");
        rollno = sc.nextInt();
        sc.nextLine();
        
        System.out.print("Enter Name: ");
        name = sc.nextLine();

        System.out.print("Enter Class: ");
        className = sc.nextLine();

        System.out.print("Enter Percentage: ");
        per = sc.nextDouble();
    }

    void displayStudent() {
        System.out.println("\n--- Student Details ---");
        System.out.println("Roll Number: " + rollno);
        System.out.println("Name       : " + name);
        System.out.println("Class      : " + className);
        System.out.println("Percentage : " + per);
    }
}

public class StudentInfo {
    public static void main(String[] args) {
        Student s = new Student();

        s.Student();

        s.displayStudent();
    }
}
