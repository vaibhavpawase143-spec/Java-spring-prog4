import java.util.Scanner;

public class NameFormat {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter full name (first middle last): ");
        String fullName = sc.nextLine().trim();

        String[] nameParts = fullName.split("\\s+");

        if (nameParts.length != 3) {
            System.out.println("Please enter name in the format: first middle last");
            return;
        }

        String first = nameParts[0];
        String middle = nameParts[1];
        String last = nameParts[2];

        middle = middle.substring(0, 1).toUpperCase() + middle.substring(1).toLowerCase();

        System.out.println("Formatted Name: " + last + ", " + first + " " + middle);
    }
}
