import java.util.Scanner;

public class MatrixMenu {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter size of square matrix (n x n): ");
        int n = sc.nextInt();

        int[][] matrix = new int[n][n];

        System.out.println("\nEnter elements of the matrix:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print("Element [" + i + "][" + j + "]: ");
                matrix[i][j] = sc.nextInt();
            }
        }

        int choice;
        do {
            // Display menu
            System.out.println("\n--- Menu ---");
            System.out.println("1. Sum of diagonal elements");
            System.out.println("2. Sum of upper diagonal elements");
            System.out.println("3. Sum of lower diagonal elements");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    int diagSum = 0;
                    for (int i = 0; i < n; i++) {
                        diagSum += matrix[i][i];
                    }
                    System.out.println("Sum of diagonal elements: " + diagSum);
                    break;

                case 2:
                    int upperSum = 0;
                    for (int i = 0; i < n; i++) {
                        for (int j = i + 1; j < n; j++) { 
                            upperSum += matrix[i][j];
                        }
                    }
                    System.out.println("Sum of upper diagonal elements: " + upperSum);
                    break;

                case 3:
                    int lowerSum = 0;
                    for (int i = 1; i < n; i++) {
                        for (int j = 0; j < i; j++) { 
                            lowerSum += matrix[i][j];
                        }
                    }
                    System.out.println("Sum of lower diagonal elements: " + lowerSum);
                    break;

                case 4:
                    System.out.println("Exiting program...");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }
        } while (choice != 4);
    }
}
