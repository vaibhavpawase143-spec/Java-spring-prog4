import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentNamesSort {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();
        sc.nextLine();

        ArrayList<String> students = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            System.out.print("Enter name of student " + (i + 1) + ": ");
            String name = sc.nextLine();
            students.add(name);
        }

        Collections.sort(students);

        System.out.println("\nStudent names in ascending order:");
        for (String name : students) {
            System.out.println(name);
        }

        sc.close();
    }
}
