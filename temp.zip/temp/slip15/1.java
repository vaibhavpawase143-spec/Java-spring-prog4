import java.util.Scanner;

class Sphere {
    double radius;
    Sphere(double r) {
        radius = r;
    }
    double surfaceArea() {
        return 4 * 3.14 * radius * radius;
    }
    double volume() {
        return (4.0 / 3) * 3.14 * radius * radius * radius;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter radius of sphere: ");
        double r = sc.nextDouble();

        Sphere s = new Sphere(r);

        System.out.println("Surface Area of Sphere = " + s.surfaceArea());
        System.out.println("Volume of Sphere = " + s.volume());
    }
}
