import java.util.Scanner;
abstract class Order {
    int id;
    String description;

    abstract void accept();
    abstract void display();
}
class PurchaseOrder extends Order {
    String customerName;

    void accept() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Purchase Order ID: ");
        id = sc.nextInt();
        sc.nextLine(); 
        System.out.print("Enter Description: ");
        description = sc.nextLine();
        System.out.print("Enter Customer Name: ");
        customerName = sc.nextLine();
    }

    void display() {
        System.out.println("\n--- Purchase Order Details ---");
        System.out.println("Order ID: " + id);
        System.out.println("Description: " + description);
        System.out.println("Customer Name: " + customerName);
    }
}
class SalesOrder extends Order {
    String vendorName;

    void accept() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Sales Order ID: ");
        id = sc.nextInt();
        sc.nextLine(); 
        System.out.print("Enter Description: ");
        description = sc.nextLine();
        System.out.print("Enter Vendor Name: ");
        vendorName = sc.nextLine();
    }

    void display() {
        System.out.println("\n--- Sales Order Details ---");
        System.out.println("Order ID: " + id);
        System.out.println("Description: " + description);
        System.out.println("Vendor Name: " + vendorName);
    }
}
public class Main {
    public static void main(String[] args) {
        PurchaseOrder[] pOrders = new PurchaseOrder[3];
        SalesOrder[] sOrders = new SalesOrder[3];

        System.out.println("=== Enter Details for 3 Purchase Orders ===");
        for (int i = 0; i < 3; i++) {
            pOrders[i] = new PurchaseOrder();
            pOrders[i].accept();
        }

        System.out.println("\n=== Enter Details for 3 Sales Orders ===");
        for (int i = 0; i < 3; i++) {
            sOrders[i] = new SalesOrder();
            sOrders[i].accept();
        }

        System.out.println("\n===== Displaying All Purchase Orders =====");
        for (int i = 0; i < 3; i++) {
            pOrders[i].display();
        }

        System.out.println("\n===== Displaying All Sales Orders =====");
        for (int i = 0; i < 3; i++) {
            sOrders[i].display();
        }
    }
}
