import sy.SYMarks;
import ty.TYMarks;
import java.util.Scanner;
class Student {
    int rollNumber;
    String name;
    SYMarks syMarks;
    TYMarks tyMarks;

    public Student(int rollNumber, String name, SYMarks syMarks, TYMarks tyMarks) {
        this.rollNumber = rollNumber;
        this.name = name;
        this.syMarks = syMarks;
        this.tyMarks = tyMarks;
    }

    public int totalComputerMarks() {
        return syMarks.computerTotal + tyMarks.theory + tyMarks.practicals;
    }

    public String getGrade(int total) {
        if (total >= 75)
            return "A";
        else if (total >= 60)
            return "B";
        else if (total >= 50)
            return "C";
        else if (total >= 40)
            return "Pass Class";
        else
            return "FAIL";
    }

    public void display() {
        int total = totalComputerMarks();
        System.out.println("\nRoll No: " + rollNumber);
        System.out.println("Name   : " + name);
        System.out.println("Total Computer Marks (SY + TY): " + total);
        System.out.println("Grade  : " + getGrade(total));
    }
}

public class StudentMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();
        sc.nextLine(); // consume newline

        Student[] students = new Student[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Student " + (i + 1));

            System.out.print("Roll Number: ");
            int roll = sc.nextInt();
            sc.nextLine();

            System.out.print("Name: ");
            String name = sc.nextLine();

            System.out.print("SY Computer Total: ");
            int syComp = sc.nextInt();

            System.out.print("SY Maths Total: ");
            int syMath = sc.nextInt();

            System.out.print("SY Electronics Total: ");
            int syElectronics = sc.nextInt();

            System.out.print("TY Theory Marks: ");
            int tyTheory = sc.nextInt();

            System.out.print("TY Practical Marks: ");
            int tyPractical = sc.nextInt();

            SYMarks sy = new SYMarks(syComp, syMath, syElectronics);
            TYMarks ty = new TYMarks(tyTheory, tyPractical);
            students[i] = new Student(roll, name, sy, ty);
        }

        System.out.println("\n--- Student Results ---");
        for (Student s : students) {
            s.display();
        }

        sc.close();
    }
}
