import java.util.Scanner;

class Student {
    int roll_no;
    String name;
    double percentage;

    void accept() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Roll Number: ");
        roll_no = sc.nextInt();
        sc.nextLine(); 
        System.out.print("Enter Name: ");
        name = sc.nextLine();
        System.out.print("Enter Percentage: ");
        percentage = sc.nextDouble();
    }

    void display() {
        System.out.printf("%-10d %-15s %-10.2f\n", roll_no, name, percentage);
    }

    static void sortStudent(Student[] students) {
        for (int i = 0; i < students.length - 1; i++) {
            for (int j = i + 1; j < students.length; j++) {
                if (students[i].percentage > students[j].percentage) {
                    Student temp = students[i];
                    students[i] = students[j];
                    students[j] = temp;
                }
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();

        Student[] students = new Student[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Student " + (i + 1) + ":");
            students[i] = new Student();
            students[i].accept();
        }

        Student.sortStudent(students);

        System.out.println("\n--- Student Details Sorted by Percentage (Ascending) ---");
        System.out.printf("%-10s %-15s %-10s\n", "Roll No", "Name", "Percentage");
        System.out.println("--------------------------------------------------");
        for (Student s : students) {
            s.display();
        }
    }
}
