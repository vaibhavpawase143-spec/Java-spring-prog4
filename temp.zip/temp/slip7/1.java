import java.util.Scanner;

class Item {
    int item_number;
    String item_name;
    double item_price;

    static int count = 0; 
    Item() {
        item_number = 0;
        item_name = "N/A";
        item_price = 0.0;
        count++;
    }

    Item(int number, String name, double price) {
        item_number = number;
        item_name = name;
        item_price = price;
        count++;
    }

    static void displayCount() {
        System.out.println("Number of objects created: " + count);
    }

    void displayItem() {
        System.out.println("\n--- Item Details ---");
        System.out.println("Item Number: " + item_number);
        System.out.println("Item Name  : " + item_name);
        System.out.println("Item Price : " + item_price);
    }
}

public class ItemDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of items: ");
        int n = sc.nextInt();
        sc.nextLine();

        Item[] items = new Item[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Item " + (i + 1) + ":");

            System.out.print("Item Number: ");
            int number = sc.nextInt();
            sc.nextLine(); 
            System.out.print("Item Name: ");
            String name = sc.nextLine();

            System.out.print("Item Price: ");
            double price = sc.nextDouble();
            sc.nextLine();

            items[i] = new Item(number, name, price);

            Item.displayCount();
        }

        System.out.println("\n=== All Items ===");
        for (int i = 0; i < n; i++) {
            items[i].displayItem();
        }

        sc.close();
    }
}
