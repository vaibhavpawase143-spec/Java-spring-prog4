import java.util.Scanner;

public class NameFormat {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter full name (first middle last): ");
        String fullName = sc.nextLine();

        String[] nameParts = fullName.trim().split("\\s+");

        if (nameParts.length != 3) {
            System.out.println("Please enter correctly");
        } else {
            String firstName = nameParts[0];
            String middleName = nameParts[1];
            String lastName = nameParts[2];

            String middleInitial = middleName.substring(0, 1).toUpperCase();

            System.out.println("Formatted Name: " + lastName + ", " + firstName + " " + middleInitial);
        }

        sc.close();
    }
}
