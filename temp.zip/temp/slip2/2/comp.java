package string1;

public class comp {
    public void compare(String str1, String str2) {
        if (str1.equals(str2)) {
            System.out.println("The strings are equal.");
        } else {
            System.out.println("The strings are NOT equal.");
        }
    }
}
