import string1.con;
import string1.comp;

public class StringMain{
    public static void main(String[] args) {
        con conObj = new con();
        conObj.concatenate("Hello", " World");

        comp compObj = new comp();
        compObj.compare("Hello", "Hello");
    }
}