package string1;

public class con {
    public void concatenate(String str1, String str2) {
        String result = str1 + str2;
        System.out.println("Concatenated String: " + result);
    }
}
