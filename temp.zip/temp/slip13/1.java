import java.util.Scanner;

class Continent {
    protected String continent;

    Continent(String continent) {
        this.continent = continent;
    }
}

class Country extends Continent {
    protected String country;

    Country(String continent, String country) {
        super(continent);
        this.country = country;
    }
}

class State extends Country {
    private String state;
    private String place;

    State(String continent, String country, String state, String place) {
        super(continent, country);
        this.state = state;
        this.place = place;
    }

    void display() {
        System.out.println("Place: " + place);
        System.out.println("State: " + state);
        System.out.println("Country: " + country);
        System.out.println("Continent: " + continent);
    }
}

public class MultilevelInheritanceDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter continent: ");
        String cont = sc.nextLine();

        System.out.print("Enter country: ");
        String coun = sc.nextLine();

        System.out.print("Enter state: ");
        String stat = sc.nextLine();

        System.out.print("Enter place: ");
        String pl = sc.nextLine();

        State obj = new State(cont, coun, stat, pl);

        System.out.println("\n--- Place Information ---");
        obj.display();

        sc.close();
    }
}
