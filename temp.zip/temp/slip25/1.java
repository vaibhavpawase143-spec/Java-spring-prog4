import java.util.Scanner;

class Item {
    int item_number;
    String item_name;
    double item_price;

   
    Item() {
        this.item_number = 0;
        this.item_name = "Unknown";
        this.item_price = 0.0;
    }

   
    Item(int item_number, String item_name, double item_price) {
        this.item_number = item_number;
        this.item_name = item_name;
        this.item_price = item_price;
    }

   
    void display() {
        System.out.printf("Item Number: %d, Item Name: %s, Item Price: %.2f\n",
                          this.item_number, this.item_name, this.item_price);
    }
}

public class ItemTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Item[] items = new Item[5];

        for (int i = 0; i < 5; i++) {
            System.out.println("\nEnter details for Item " + (i + 1) + ":");
            System.out.print("Item Number: ");
            int number = sc.nextInt();
            sc.nextLine(); 
            System.out.print("Item Name: ");
            String name = sc.nextLine();
            System.out.print("Item Price: ");
            double price = sc.nextDouble();

            items[i] = new Item(number, name, price);
        }

        System.out.println("\n--- Item Details ---");
        for (Item item : items) {
            item.display();
        }
    }
}
